import { CiCalendar, CiLocationOn } from "react-icons/ci";
import { IoPeopleOutline } from "react-icons/io5";

export const EventCard = ({ events }) => {
  return (
    <div className="mt-8 px-8 py-6 rounded-lg shadow-md">
      <div className="grid grid-cols-1 md:grid-cols-3 ml-2 gap-4">
        {events.map((events, index) => (
          <div key={index} className="p-6 border border-gray-200 rounded-lg shadow-md bg-white flex flex-col h-full w-full md:w-[40rem] md:h-[40rem]">
            <img src={events.imageUrl} alt="Event" className="w-full h-[17rem] object-cover rounded-md" />
            <div className="mt-6 flex-grow">
              <h5 className="text-3xl font-semibold">{events.name}</h5>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <CiCalendar className="w-10 h-10 mr-3 text-[#5171B4] mb-1" />
                {events.date},&nbsp;&nbsp;{events.time}
              </p>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <CiLocationOn className="w-10 h-10 mr-3 text-[#5171B4]" />
                {events.location}
              </p>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <IoPeopleOutline className="w-10 h-10 mr-3 text-[#5171B4]" />
                {events.participants} out of {events.capacity} have joined
              </p>
            </div>
            <button className="mt-6 w-full text-xl text-white bg-[#5A71B4] hover:bg-[#4a5c94] font-medium py-4 rounded-md">
              Read More
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
 export default EventCard;
