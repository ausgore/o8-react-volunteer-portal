import React, { useEffect, useState } from 'react';
import { IoMdClose } from 'react-icons/io';
import ProgressBar from 'progressbar.js';

const ProgressAlert = ({ message, show, onClose, success }) => {
  const [isVisible, setIsVisible] = useState(false);

  useEffect(() => {
    let interval2;
    let hideTimeout;
    let slideUpTimeout;

    if (show) {
      setIsVisible(true);

      // Determine color based on success or failure
      const color = success ? '#28a745' : '#dc3545'; // Green for success, Red for failure
      const trailColor = success ? '#d4edda' : '#f8d7da'; // Lighter green or red for trail

      // Initialize progress bar
      const bar = new ProgressBar.Circle('#progress-container', {
        strokeWidth: 5,
        easing: 'easeInOutExpo',
        duration: 3000, // 3 seconds duration
        color: color, // Color for progress bar
        trailColor: trailColor, // Trail color
        trailWidth: 5,
        svgStyle: null,
        from: { color: color, width: 5 },
        to: { color: color, width: 5 },
        step: function (state, circle) {
          circle.path.setAttribute('stroke', state.color);
          circle.path.setAttribute('stroke-width', state.width);
          const value = Math.round(circle.value() * 100);
          if (value === 0) {
            circle.setText('');
          } else {
            circle.setText(value);
          }
        },
      });

      // Hide the progress bar text
      bar.text.style.color = 'transparent';
      bar.animate(1.0); // Start the animation

      // Check for completion
      interval2 = setInterval(() => {
        const progressBarText = document.querySelector('div.progressbar-text');
        if (progressBarText && progressBarText.textContent === '100') {
          clearInterval(interval2);
          // Animate the white circle to disappear
          const whiteCircle = document.querySelector('div#whitecircle div');
          if (whiteCircle) {
            whiteCircle.style.transition = 'width 0.333s, height 0.333s';
            whiteCircle.style.width = '0';
            whiteCircle.style.height = '0';
          }

          // Animate the tick mark or X mark to appear
          setTimeout(() => {
            const tick = document.querySelector('div#tick div');
            if (tick) {
              tick.style.transition = 'font-size 0.333s';
              tick.style.fontSize = '40px'; // Smaller tick or X size
            }
          }, 333);
        }
      }, 100);

      // Timeout to hide the alert after the progress bar finishes
      hideTimeout = setTimeout(() => {
        setIsVisible(false);
        slideUpTimeout = setTimeout(onClose, 500); // Ensure the alert slides up before onClose is called
      }, 3500); // 3000ms for progress bar + 500ms for sliding up
    } else {
      hideTimeout = setTimeout(() => {
        setIsVisible(false);
        slideUpTimeout = setTimeout(onClose, 500); // Ensure the alert slides up before onClose is called
      }, 500); // Match the duration of the transition
    }

    // Cleanup function to clear interval and timeout
    return () => {
      clearInterval(interval2);
      clearTimeout(hideTimeout);
      clearTimeout(slideUpTimeout);
    };
  }, [show, success, onClose]);

  // Return null if not visible
  if (!isVisible && !show) return null;

  return (
    <div
      className={`fixed top-0 inset-x-0 flex items-center justify-center z-50 transition-transform duration-500 transform ${
        show ? 'translate-y-0' : '-translate-y-full'
      } mt-8`}
    >
      <div className="bg-white rounded-xl p-8 w-full max-w-lg relative shadow-lg">
        <button
          className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
          onClick={() => {
            setIsVisible(false);
            setTimeout(onClose, 500); // Ensure the alert slides up before onClose is called
          }}
        >
          <IoMdClose size={24} />
        </button>
        <div className="text-center">
          {/* Progress bar container */}
          <div id="progress-container" className="relative w-[6rem] h-[6rem] mx-auto">
            {/* Background circle */}
            <div id="bkground" className="flex items-center justify-center absolute w-full h-full">
              <div className={`w-[5rem] h-[5rem] rounded-full ${success ? 'bg-green-300' : 'bg-red-300'}`}></div>
            </div>
            {/* White circle */}
            <div id="whitecircle" className="flex items-center justify-center absolute w-full h-full">
              <div className="w-[5rem] h-[5rem] bg-white rounded-full"></div>
            </div>
            {/* Tick or X mark */}
            <div id="tick" className="flex items-center justify-center absolute w-full h-full">
              <div className={`font-bold text-0 ${success ? 'text-green-200' : 'text-red-200'}`}>{success ? '✔' : '✖'}</div>
            </div>
          </div>
          <h2 className="text-2xl font-semibold mt-4">{message}</h2>
        </div>
      </div>
    </div>
  );
};

export default ProgressAlert;
