import { AiOutlinePhone, AiOutlineMail } from "react-icons/ai";
import { FiEdit } from "react-icons/fi";
import { Link } from "react-router-dom"; // Import Link from react-router-dom

export const DashboardHeader = ({ name, email, phone, imageUrl }) => {
    return (
        <div
            className="relative p-10 pl-20 shadow-md flex justify-between items-center rounded-lg m-8 bg-opacity-31"
            style={{ backgroundColor: "rgba(169, 183, 224, 0.31)" }}
        >
            <div className="flex items-center w-full">
                <div className="">
                    <img
                        src={imageUrl}
                        alt="Profile"
                        className="w-[100px] h-[100px] rounded-full bg-white overflow-hidden"
                    />
                </div>
                <div className="flex flex-col md:flex-row items-start md:items-center w-full h-[10rem]">
                    <h1 className="font-semibold md:text-5xl mb-2 md:mb-0 ml-10 flex items-center justify-start">
                        {name}
                    </h1>
                    <div className="flex flex-col items-start md:items-center ml-auto mr-[6rem]">
                        <p className="text-2xl flex items-center mb-2 md:mb-7 font-semibold">
                            <AiOutlineMail className=" md:text-3xl mr-2 text-[#5A71B4] hover:text-[#495b92] cursor-pointer" />
                            {email}
                        </p>
                        <p className="text-2xl flex items-center font-semibold ml-[-5.2rem]">
                            <AiOutlinePhone className="md:text-3xl mr-2 text-[#5A71B4] hover:text-[#495b92] cursor-pointer" />
                            {phone}
                        </p>
                    </div>
                </div>
            </div>
            <div className="absolute top-5 right-5">
                <Link to="/profile">
                    <button className="text-[#5A71B4] hover:text-[#495b92]">
                        <FiEdit className="w-8 h-8"/>
                    </button>
                </Link>
            </div>
        </div>
    );
};
