import { useState } from "react";
import { BsThreeDotsVertical } from "react-icons/bs";
import { GrView } from "react-icons/gr";
import { AiOutlineStop } from "react-icons/ai";
import CancelEvent from "../assets/undraw_cancel_re_pkdm.svg";

export const EventStatus = ({ events }) => {
  const statusStyles = {
    "Upcoming": "bg-[#FFB656] text-white",
    "No Show": "bg-gray-400 text-white",
    "Canceled": "bg-[#F26A6A] text-white",
    "Completed": "bg-[#7BCF72] text-white"
  };

  const [currentPage, setCurrentPage] = useState(1);
  const [openMenuIndex, setOpenMenuIndex] = useState(null);
  const [showCancelModal, setShowCancelModal] = useState(false);
  const eventsPerPage = 5;

  // Calculate the total number of pages
  const totalPages = Math.ceil(events.length / eventsPerPage);

  // Get the events to display on the current page
  const currentEvents = events.slice((currentPage - 1) * eventsPerPage, currentPage * eventsPerPage);

  // Handler for the previous button
  const handlePrevious = () => {
    if (currentPage > 1) {
      setCurrentPage(currentPage - 1);
    }
  };

  // Handler for the next button
  const handleNext = () => {
    if (currentPage < totalPages) {
      setCurrentPage(currentPage + 1);
    }
  };

  // Toggle menu visibility
  const toggleMenu = (index) => {
    setOpenMenuIndex(openMenuIndex === index ? null : index);
  };

  // Handle Cancel button click
  const handleCancelClick = () => {
    setShowCancelModal(true);
    setOpenMenuIndex(null); // Close the dropdown menu
  };

  // Close modal
  const closeModal = () => {
    setShowCancelModal(false);
  };

  return (
    <div className="mt-5 p-9 rounded-lg">
      <h2 className="text-4xl font-semibold text-black mb-10">Volunteering Event Status</h2>
      <table className="min-w-full divide-y divide-gray-200 table-fixed">
        <thead className="bg-white">
          <tr>
            <th className="px-6 py-5 text-left text-3xl font-medium text-black w-3/12">Event Name</th>
            <th className="px-6 py-5 text-left text-3xl font-medium text-black w-3/12">Date & Time</th>
            <th className="px-6 py-5 text-left text-3xl font-medium text-black w-2/12">Status</th>
            <th className="px-6 py-5 text-left text-3xl font-medium text-black w-3/12">Location</th>
            <th className="px-6 py-5 text-left text-3xl font-medium text-black w-1/12">Action</th>
          </tr>
        </thead>
        <tbody className="bg-white divide-y divide-gray-200">
          {currentEvents.map((event, index) => (
            <tr key={index}>
              <td className="px-3 text-2xl py-4 whitespace-nowrap pl-6">{event.name}</td>
              <td className="px-3 text-2xl py-4 whitespace-nowrap">{event.dateTime}</td>
              <td className="px-3 text-2xl py-4 whitespace-nowrap">
                <span className={`px-4 inline-flex text-[1.2rem] leading-8 font-semibold rounded-md ${statusStyles[event.status]}`}>
                  {event.status}
                </span>
              </td>
              <td className="px-3 text-2xl py-4 whitespace-nowrap">{event.location}</td>
              <td className="px-3 text-2xl py-4 whitespace-nowrap relative">
                <button className="text-gray-500 hover:text-gray-700" onClick={() => toggleMenu(index)}>
                  <BsThreeDotsVertical className="h-10 w-10 ml-8" />
                </button>
                {openMenuIndex === index && (
                  <div className="absolute right-0 w-40 bg-white shadow-lg rounded-md z-10">
                    <ul>
                      <li className="px-4 py-2 hover:bg-gray-100 flex items-center">
                        <GrView className="mr-2" /> View
                      </li>
                      <li className="px-4 py-2 hover:bg-gray-100 flex items-center" onClick={handleCancelClick}>
                        <AiOutlineStop className="mr-2 text-black" /> Cancel
                      </li>
                    </ul>
                  </div>
                )}
              </td>
            </tr>
          ))}
        </tbody>
      </table>
      <div className="flex justify-between items-center mt-4">
        <span className="text-xl text-gray-500 mb-5">
          Showing {((currentPage - 1) * eventsPerPage) + 1} to {Math.min(currentPage * eventsPerPage, events.length)} of {events.length} entries
        </span>
        <div className="flex items-center space-x-2">
          <button
            className={`px-2 py-4 text-3xl font-medium rounded ${currentPage === 1 ? 'text-gray-400 cursor-not-allowed' : 'text-gray-700 hover:text-black'}`}
            onClick={handlePrevious}
            disabled={currentPage === 1}
          >
            &laquo;
          </button>
          <span className="text-3xl font-medium text-gray-700">{currentPage}</span>
          <button
            className={`px-2 py-4 text-3xl font-medium rounded ${currentPage === totalPages ? 'text-gray-400 cursor-not-allowed' : 'text-gray-700 hover:text-black'}`}
            onClick={handleNext}
            disabled={currentPage === totalPages}
          >
            &raquo;
          </button>
        </div>
      </div>

      {showCancelModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-70 flex justify-center items-center z-50 backdrop-blur-md">
          <div className="bg-white p-8 pt-[5rem] rounded-xl shadow-lg relative w-[90%] max-w-lg h-[400px]">
            <button className="absolute top-0 right-0 mt-4 mr-4 text-gray-600 text-3xl font-semibold" onClick={closeModal}>
              &times;
            </button>
            <img src={CancelEvent} alt="Cancel Event" className="w-[170px] h-[170px] mx-auto mb-4" />
            <h3 className="text-2xl font-semibold text-center mb-4 text-gray-600">
              Are you sure you want to <br /> cancel this event?
            </h3>
            <div className="flex flex-col items-center space-y-4">
              <button className="px-[8rem]  py-4 mt-2 text-xl bg-[#5A71B4] text-white rounded-md" onClick={closeModal}>
                Confirm
              </button>
              <button
                className="px-[8rem] py-4 text-xl text-gray-600 rounded-md hover:bg-gray-200"
                onClick={closeModal}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
