import { useState, useEffect, KeyboardEvent } from "react";
import { IoIosArrowDown } from "react-icons/io";
import { FaMagnifyingGlass } from "react-icons/fa6";
import { CiCalendar, CiClock1 } from "react-icons/ci";
import { useSearchParams } from "react-router-dom";
import AllEventCard from "../components/AllEventCard";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

// Sample data
const AllEventsData = [
  {
    id: 1,
    name: "Serving Those in Need",
    date: "2024-04-19",
    time: "12:00 PM",
    startTime: "12:00",
    endTime: "17:00",
    location: "One North St 5",
    participants: 20,
    capacity: 30,
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIROUEKN4tw1c26UjDHnI4RVQBE-YUzS1rJOKShywLnw&s",
    category: "Social Services",
  },
  {
    id: 2,
    name: "Protecting Our Natural Habitat",
    date: "2024-09-24",
    time: "10:30 AM",
    startTime: "10:30",
    endTime: "13:30",
    location: "Lim Chu Kang St 12",
    participants: 15,
    capacity: 30,
    imageUrl:
      "https://media.hswstatic.com/eyJidWNrZXQiOiJjb250ZW50Lmhzd3N0YXRpYy5jb20iLCJrZXkiOiJnaWZcL3ZvbHVudGVlci1vcHBvcnR1bml0aWVzLWZvci1raWRzLTEuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoyOTB9fX0=",
    category: "Animal Welfare",
  },
  {
    id: 3,
    name: "Making Our Neighborhood Shine",
    date: "2024-12-07",
    time: "08:00 AM",
    startTime: "08:00",
    endTime: "10:00",
    location: "East Coast Park",
    participants: 7,
    capacity: 20,
    imageUrl:
      "https://imagedelivery.net/WLUarKbmUXuuhDC7PG5_Qw/articles/fa4987215325b577b319ff0bd8020a7d.jpg/public",
    category: "Community Service",
  },
  {
    id: 4,
    name: "Community Cleanup",
    date: "2024-05-15",
    time: "09:00 AM",
    startTime: "09:00",
    endTime: "11:00",
    location: "Buona Vista",
    participants: 25,
    capacity: 40,
    imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIROUEKN4tw1c26UjDHnI4RVQBE-YUzS1rJOKShywLnw&s",
    category: "Social Services",
  },
  {
    id: 5,
    name: "Beach Cleanup",
    date: "2024-07-21",
    time: "07:00 AM",
    startTime: "07:00",
    endTime: "09:30",
    location: "East Coast Park",
    participants: 50,
    capacity: 60,
    imageUrl: "https://media.hswstatic.com/eyJidWNrZXQiOiJjb250ZW50Lmhzd3N0YXRpYy5jb20iLCJrZXkiOiJnaWZcL3ZvbHVudGVlci1vcHBvcnR1bml0aWVzLWZvci1raWRzLTEuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoyOTB9fX0=",
    category: "Community Service",
  },
  {
    id: 6,
    name: "Park Beautification",
    date: "2024-08-10",
    time: "10:00 AM",
    startTime: "10:00",
    endTime: "14:00",
    location: "Bishan-Ang Mo Kio Park",
    participants: 30,
    capacity: 40,
    imageUrl: "https://imagedelivery.net/WLUarKbmUXuuhDC7PG5_Qw/articles/fa4987215325b577b319ff0bd8020a7d.jpg/public",
    category: "Social Services",
  },
  {
    id: 7,
    name: "River Cleanup",
    date: "2024-11-11",
    time: "08:30 AM",
    startTime: "08:30",
    endTime: "11:30",
    location: "Bukit Batok",
    participants: 20,
    capacity: 25,
    imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIROUEKN4tw1c26UjDHnI4RVQBE-YUzS1rJOKShywLnw&s",
    category: "Animal Welfare",
  },
  {
    id: 8,
    name: "Wildlife Conservation",
    date: "2024-03-22",
    time: "01:00 PM",
    startTime: "13:00",
    endTime: "17:00",
    location: "Lim Chu Kang St 12",
    participants: 35,
    capacity: 40,
    imageUrl: "https://media.hswstatic.com/eyJidWNrZXQiOiJjb250ZW50Lmhzd3N0YXRpYy5jb20iLCJrZXkiOiJnaWZcL3ZvbHVudGVlci1vcHBvcnR1bml0aWVzLWZvci1raWRzLTEuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoyOTB9fX0=",
    category: "Animal Welfare",
  },
  {
    id: 9,
    name: "Urban Gardening Workshop",
    date: "2024-06-30",
    time: "02:00 PM",
    startTime: "14:00",
    endTime: "16:00",
    location: "Buona Vista",
    participants: 10,
    capacity: 15,
    imageUrl: "https://imagedelivery.net/WLUarKbmUXuuhDC7PG5_Qw/articles/fa4987215325b577b319ff0bd8020a7d.jpg/public",
    category: "Social Services",
  },
];

const locations = [
  "North",
  "South",
  "East",
  "West",
];

export default function AllEvent() {
  const [events, setEvents] = useState(AllEventsData);
  const [search, setSearch] = useState("");
  const [categories] = useState([
    "Social Services",
    "Animal Welfare",
    "Community Service",
  ]);
  const [searchParams, setSearchParams] = useSearchParams();
  const [selectedDate, setSelectedDate] = useState(null);
  const [startTime, setStartTime] = useState(null);
  const [endTime, setEndTime] = useState(null);
  const [showDateDropdown, setShowDateDropdown] = useState(false);
  const [showCategoryDropdown, setShowCategoryDropdown] = useState(false);
  const [showLocationDropdown, setShowLocationDropdown] = useState(false);
  const [selectedLocations, setSelectedLocations] = useState([]);

  // Handle search input
  const handleSearch = (e) => {
    if (e.key === "Enter") {
      if (search.length) searchParams.set("search", search);
      else searchParams.delete("search");
      setSearchParams(searchParams);
    }
  };

  // Update events when searchParams change
  useEffect(() => {
    updateEvents();
  }, [searchParams]);

  // Function to filter events based on searchParams
  const updateEvents = () => {
    let filteredEvents = AllEventsData;

    const search = searchParams.get("search");
    if (search) {
      filteredEvents = filteredEvents.filter((event) =>
        event.name.toLowerCase().includes(search.toLowerCase())
      );
    }

    const selectedCategories = JSON.parse(
      searchParams.get("categories") ?? "[]"
    );
    if (selectedCategories.length > 0) {
      filteredEvents = filteredEvents.filter((event) =>
        selectedCategories.includes(event.category)
      );
    }

    // Date filter
    const date = searchParams.get("date");
    if (date) {
      filteredEvents = filteredEvents.filter(
        (event) => {
          const filteredDate = new Date(date);
          filteredDate.setDate(filteredDate.getDate() + 1);
          return new Date(event.date).getTime() === filteredDate.getTime()
        }
      );
    }

    // Time filter
    const start = searchParams.get("startTime");
    const end = searchParams.get("endTime");
    if (start || end) {
      filteredEvents = filteredEvents.filter((event) => {
        const eventStart = new Date(`1970-01-01T${event.startTime}`).getTime();
        const eventEnd = new Date(`1970-01-01T${event.endTime}`).getTime();
        if (start && end) {
          const filterStart = new Date(`1970-01-01T${start}`).getTime();
          const filterEnd = new Date(`1970-01-01T${end}`).getTime();
          return eventStart >= filterStart && eventEnd <= filterEnd;
        } else if (start) {
          const filterStart = new Date(`1970-01-01T${start}`).getTime();
          return eventStart >= filterStart;
        } else if (end) {
          const filterEnd = new Date(`1970-01-01T${end}`).getTime();
          return eventEnd <= filterEnd;
        }
        return true;
      });
    }

    // Location filter
    const selectedLocations = JSON.parse(
      searchParams.get("locations") ?? "[]"
    );
    if (selectedLocations.length > 0) {
      filteredEvents = filteredEvents.filter((event) =>
        selectedLocations.includes(event.location)
      );
    }

    setEvents(filteredEvents);
  };

  // Toggle category dropdown
  const handleCategoryDropdown = () =>
    setShowCategoryDropdown(!showCategoryDropdown);

  // Update selected categories
  const updateSelectedCategories = (category) => {
    const selectedCategories = JSON.parse(
      searchParams.get("categories") ?? "[]"
    );
    if (!selectedCategories.includes(category))
      selectedCategories.push(category);
    else selectedCategories.splice(
      selectedCategories.indexOf(category),
      1
    );

    if (!selectedCategories.length) searchParams.delete("categories");
    else searchParams.set("categories", JSON.stringify(selectedCategories));
    setSearchParams(searchParams);
  };

  // Toggle date dropdown
  const handleDateDropdown = () => setShowDateDropdown(!showDateDropdown);

  // Update selected date
  const updateSelectedDate = (date) => {
    setSelectedDate(date);
    if (date) {
      searchParams.set("date", date.toISOString().substring(0, 10));
    } else {
      searchParams.delete("date");
    }
    setSearchParams(searchParams);
  };    

  // Update selected start time
  const updateStartTime = (time) => {
    setStartTime(time);
    if (time) {
      const timeString = time.toTimeString().substring(0, 5);
      searchParams.set("startTime", timeString);
    } else {
      searchParams.delete("startTime");
    }
    setSearchParams(searchParams);
  };

  // Update selected end time
  const updateEndTime = (time) => {
    setEndTime(time);
    if (time) {
      const timeString = time.toTimeString().substring(0, 5);
      searchParams.set("endTime", timeString);
    } else {
      searchParams.delete("endTime");
    }
    setSearchParams(searchParams);
  };

  // Toggle location dropdown
  const handleLocationDropdown = () => setShowLocationDropdown(!showLocationDropdown);

  // Update selected locations
  const updateSelectedLocations = (location) => {
    const selectedLocations = JSON.parse(
      searchParams.get("locations") ?? "[]"
    );
    if (!selectedLocations.includes(location))
      selectedLocations.push(location);
    else selectedLocations.splice(
      selectedLocations.indexOf(location),
      1
    );

    setSelectedLocations(selectedLocations);

    if (!selectedLocations.length) searchParams.delete("locations");
    else searchParams.set("locations", JSON.stringify(selectedLocations));
    setSearchParams(searchParams);
  };

  // Clear all filters
  const clearFilters = () => {
    setSearch("");
    setSelectedDate(null);
    setStartTime(null);
    setEndTime(null);
    setSelectedLocations([]);
    searchParams.delete("search");
    searchParams.delete("categories");
    searchParams.delete("date");
    searchParams.delete("startTime");
    searchParams.delete("endTime");
    searchParams.delete("locations");
    setSearchParams(searchParams);
  };

  // Format date for display
  const formatDate = (dateStr) => {
    const options = { year: "numeric", month: "long", day: "numeric" };
    return new Date(dateStr).toLocaleDateString(undefined, options);
  };

  // Handle click outside of dropdowns to close them
  const handleClickOutside = (event) => {
    if (
      !event.target.closest(".category-dropdown") &&
      showCategoryDropdown
    ) {
      setShowCategoryDropdown(false);
    }
    if (!event.target.closest(".date-dropdown") && showDateDropdown) {
      setShowDateDropdown(false);
    }
    if (!event.target.closest(".location-dropdown") && showLocationDropdown) {
      setShowLocationDropdown(false);
    }
  };

  // Add event listener to handle clicks outside of dropdowns
  useEffect(() => {
    document.addEventListener("mousedown", handleClickOutside);
    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  });

  return (
    <div className="p-4 mb-12">
      <div className="max-w-[1200px] px-0 md:px-6">
        {/* This is for the topbar */}
        <div className="mb-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 items-center gap-y-5 lg:gap-x-6 ml-11">
          {/* Search function */}
          <div className="relative flex items-center col-span-5 lg:col-span-1">
            <input
              type="text"
              placeholder="Search"
              className="py-4 px-6 pr-16 rounded-lg w-full outline-none"
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              onKeyDown={handleSearch}
            />
            <FaMagnifyingGlass className="text-gray-500 absolute right-6 top-1/2 transform -translate-y-1/2 pointer-events-none" />
          </div>
          <div className="col-span-5 lg:col-span-4 flex flex-col md:grid md:grid-cols-4 lg:flex lg:flex-row justify-between lg:justify-normal gap-4">
            {/* Category */}
            <div className="relative w-full lg:w-[250px]">
              {/* Button */}
              <button
                className="bg-[#5A71B4] text-white flex justify-between px-6 py-4 rounded-md items-center w-full category-dropdown"
                onClick={handleCategoryDropdown}
              >
                <span>Category</span>
                <IoIosArrowDown />
              </button>
              {/* Dropdown */}
              {showCategoryDropdown && (
                <div className="absolute bg-white shadow-md rounded-md w-full min-w-[250px] mt-2 z-50 category-dropdown">
                  {categories.map((category) => (
                    <div
                      key={category}
                      className="inline-block px-6 py-4 items-center gap-x-3 cursor-pointer hover:bg-gray-100 w-full"
                      onClick={() => updateSelectedCategories(category)}
                    >
                      <input
                        type="checkbox"
                        id={`${category}`}
                        className="pointer-events-none"
                        checked={JSON.parse(
                          searchParams.get("categories") ?? "[]"
                        ).includes(category)}
                      />
                      <label
                        htmlFor={`${category}`}
                        className="text-sm w-full text-gray-600 ml-4 cursor-pointer pointer-events-none"
                      >
                        {category}
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Date and Time */}
            <div className="relative w-full lg:w-[250px]">
              <button
                className="bg-[#5A71B4] text-white flex justify-between px-6 py-4 rounded-md items-center w-full date-dropdown"
                onClick={handleDateDropdown}
              >
                <span>Date & Time</span>
                <IoIosArrowDown />
              </button>
              {/* Dropdown */}
              {showDateDropdown && (
                <div className="absolute bg-white shadow-md rounded-md w-full min-w-[300px] mt-2 z-50 p-4 date-dropdown">
                  <div className="flex items-center mb-4">
                    <CiCalendar className="text-2xl text-gray-600 mr-2" />
                    <DatePicker
                      selected={selectedDate}
                      onChange={updateSelectedDate}
                      className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                  <div className="flex items-center mb-4">
                    <CiClock1 className="text-2xl text-gray-600 mr-2" />
                    <DatePicker
                      selected={startTime}
                      onChange={updateStartTime}
                      showTimeSelect
                      showTimeSelectOnly
                      timeIntervals={15}
                      timeCaption="Start Time"
                      dateFormat="HH:mm"
                      className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                    <span className="mx-2">-</span>
                    <DatePicker
                      selected={endTime}
                      onChange={updateEndTime}
                      showTimeSelect
                      showTimeSelectOnly
                      timeIntervals={15}
                      timeCaption="End Time"
                      dateFormat="HH:mm"
                      className="mt-1 block w-full px-4 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm"
                    />
                  </div>
                </div>
              )}
            </div>

            {/* Location */}
            <div className="relative w-full lg:w-[250px]">
              <button
                className="bg-[#5A71B4] text-white flex justify-between px-6 py-4 rounded-md items-center w-full location-dropdown"
                onClick={handleLocationDropdown}
              >
                <span>Location</span>
                <IoIosArrowDown />
              </button>
              {/* Dropdown */}
              {showLocationDropdown && (
                <div className="absolute bg-white shadow-md rounded-md w-full min-w-[250px] mt-2 z-50 location-dropdown">
                  {locations.map((location) => (
                    <div
                      key={location}
                      className="inline-block px-6 py-4 items-center gap-x-3 cursor-pointer hover:bg-gray-100 w-full"
                      onClick={() => updateSelectedLocations(location)}
                    >
                      <input
                        type="checkbox"
                        id={`${location}`}
                        className="pointer-events-none"
                        checked={JSON.parse(
                          searchParams.get("locations") ?? "[]"
                        ).includes(location)}
                      />
                      <label
                        htmlFor={`${location}`}
                        className="text-sm w-full text-gray-600 ml-4 cursor-pointer pointer-events-none"
                      >
                        {location}
                      </label>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {/* Clear Filters Button */}
            <div className="relative w-full lg:w-[250px]">
              <button
                className="text-[#5A71B4] hover:underline text-lg px-4 py-2 rounded-md"
                onClick={clearFilters}
              >
                Clear Filters
              </button>
            </div>
          </div>
        </div>

        {/* Event cards */}
        {events.length === 0 ? (
          <h1 className="text-lg text-gray-500">
            Looks like there aren't any events
          </h1>
        ) : (
          <>
            {searchParams.get("search") && (
              <h1 className="text-xl font-semibold text-gray-600">
                Results for: {searchParams.get("search")}
              </h1>
            )}
            <AllEventCard 
            events={events.map((event) => ({
                ...event,
                date: formatDate(event.date),
              }))}
            />
          </>
        )}
      </div>
    </div>
  );
}
