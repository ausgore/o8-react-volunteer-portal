import React from 'react';
import { Link } from 'react-router-dom';
import { RxDashboard } from "react-icons/rx";
import { PiSignOutBold } from "react-icons/pi";
import { CgProfile } from "react-icons/cg";
import { FaRegCalendarAlt } from "react-icons/fa";
import Octopus8 from "../assets/octopus8-logo-landscape.png";


const Sidebar = () => {
  return (
    <aside className="profile-sidebar">
      <div className="logo-container">
        <img src={Octopus8} alt="Logo" />
      </div>

      <nav className="sidebar-nav">
        <div className="NavContainers">
          <a href="/Dashboard" className="sidebar-item">
            <RxDashboard className="DashboardIcon" /> Dashboard
          </a>
        </div>
        <div className="NavContainers">
          <a href="/profile" className="sidebar-item">
            <CgProfile className="ProfileIcon" /> Profile
          </a>
        </div>
        <div className="NavContainers">
          <a href="#" className="sidebar-item">
            <FaRegCalendarAlt className="ProfileIcon" /> All Events
          </a>
        </div>

        <div className="NavContainersLast">
          <Link to="/" className="sidebar-item">
            <PiSignOutBold className="SignOutIcon" /> Sign Out
          </Link>
        </div>
      </nav>
    </aside>
  );
}

export default Sidebar;
