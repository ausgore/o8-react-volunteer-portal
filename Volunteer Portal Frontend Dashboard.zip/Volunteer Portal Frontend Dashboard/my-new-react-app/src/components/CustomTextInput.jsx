import { FiEdit } from "react-icons/fi";
import React, { useState } from 'react';

// Text input component
export function CustomTextInput({ customField, updateCustomField }) {
  return (
    <div className="profile-form-group">
      <label>{customField.label}</label>
      <div className="profile-form-control">
        <input
          type="profileinfo"
          name={customField.name}
          value={customField.value}
          onChange={(e) => updateCustomField(customField.name, e.target.value)}
        />
        <FiEdit className="edit-icon" />
      </div>
    </div>
  );
}

// Dropdown input component
export function CustomDropdownInput({ customField, updateCustomField }) {
  return (
    <div className="profile-form-group">
      <label>{customField.label}</label>
      <div className="profile-form-control custom-dropdown">
        <select
          name={customField.name}
          value={customField.value}
          onChange={(e) => updateCustomField(customField.name, e.target.value)}
          className="dropdown-select"
        >
          
          {customField.options.map((option, index) => (
            <option key={index} value={option} className="dropdown-option">
              {option}
            </option>
          ))}
        </select>
        <div className="custom-dropdown-arrow">&#9660;</div> {/* Custom arrow */}
      </div>
    </div>
  );
}



// Checkbox input component
export function CustomCheckboxInput({ customField, updateCustomField }) {
  const [isOpen, setIsOpen] = useState(false); // State to control the dropdown visibility

  // Function to toggle the dropdown open and closed
  const toggleDropdown = () => {
    setIsOpen(!isOpen);
  };

  // Function to handle checkbox changes
  const handleChange = (option, isChecked) => {
    const newValue = isChecked
      ? [...customField.value, option]
      : customField.value.filter((value) => value !== option);
    updateCustomField(customField.name, newValue);
  };

  return (
    <div className="profile-form-group">
      <label>{customField.label}</label>
      <div className="dropdown-label" onClick={toggleDropdown}>
        {customField.label}
        <div className="dropdown-icon">▼</div>
      </div>
      {isOpen && (
        <div className="profile-form-control dropdown-checkbox">
          {customField.options.map((option, index) => (
            <label key={index} className="dropdown-option">
              {option}
              <input
                type="checkbox"
                name={customField.name}
                value={option}
                checked={customField.value.includes(option)}
                onChange={(e) => handleChange(option, e.target.checked)}
              />
            </label>
          ))}
        </div>
      )}
    </div>
  );
}




