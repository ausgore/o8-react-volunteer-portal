import { CiCalendar, CiLocationOn } from "react-icons/ci";
import { IoPeopleOutline } from "react-icons/io5";

export const UpcomingEvents = ({ events }) => {
  return (
    <div className="mt-8 px-8 py-6 rounded-lg shadow-md">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-4xl font-semibold">Upcoming Events!</h2>
        <a href="#" className="text-blue-500 hover:text-blue-700 text-2xl font-medium">View All Events &gt;</a>
      </div>
      <div className="grid grid-cols-1 md:grid-cols-3 ml-2 gap-4">
        {events.map((event, index) => (
          <div key={index} className="p-6 border border-gray-200 rounded-lg shadow-md bg-white flex flex-col h-full w-full md:w-[40rem] md:h-[40rem]">
            <img src={event.imageUrl} alt="Event" className="w-full h-[17rem] object-cover rounded-md" />
            <div className="mt-6 flex-grow">
              <h5 className="text-3xl font-semibold">{event.name}</h5>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <CiCalendar className="w-10 h-10 mr-3 text-[#5171B4] mb-1" />
                {event.dateTime}
              </p>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <CiLocationOn className="w-10 h-10 mr-3 text-[#5171B4]" />
                {event.location}
              </p>
              <p className="text-2xl text-gray-600 flex items-center mt-4">
                <IoPeopleOutline className="w-10 h-10 mr-3 text-[#5171B4]" />
                {event.participants} out of {event.capacity} have joined
              </p>
            </div>
            <button className="mt-6 w-full text-xl text-white bg-[#5A71B4] hover:bg-[#4a5c94] font-medium py-4 rounded-md">
              Read More
            </button>
          </div>
        ))}
      </div>
    </div>
  );
};
