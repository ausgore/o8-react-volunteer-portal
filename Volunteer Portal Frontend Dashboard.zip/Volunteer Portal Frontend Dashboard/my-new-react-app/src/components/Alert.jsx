// import React, { useEffect, useState } from 'react';
// import { IoMdClose } from 'react-icons/io';
// import ProgressBar from 'progressbar.js';

// const Alert = ({ message, show, onClose }) => {
//   const [isVisible, setIsVisible] = useState(false);

//   useEffect(() => {
//     if (show) {
//       setIsVisible(true);
//       var bar = new ProgressBar.Circle('#progress-container', {
//         strokeWidth: 5,
//         easing: 'easeInOutExpo',
//         duration: 1500,
//         color: '#a3a3ff',//         trailColor: '#d1d1ff',
//         trailWidth: 5,
//         svgStyle: null,
//         from: { color: '#a3a3ff', width: 5 },
//         to: { color: '#a3a3ff', width: 5 },
//         step: function (state, circle) {
//           circle.path.setAttribute('stroke', state.color);
//           circle.path.setAttribute('stroke-width', state.width);
//           var value = Math.round(circle.value() * 100);
//           if (value === 0) {
//             circle.setText('');
//           } else {
//             circle.setText(value);
//           }
//         },
//       });
//       bar.text.style.color = 'transparent';
//       bar.animate(1.0);

//       var interval2 = setInterval(function () {
//         if (document.querySelector('div.progressbar-text').textContent === '100') {
//           clearInterval(interval2);
//           document.querySelector('div#whitecircle div').style.transition = 'width 0.333s, height 0.333s';
//           document.querySelector('div#whitecircle div').style.width = '0';
//           document.querySelector('div#whitecircle div').style.height = '0';

//           setTimeout(() => {
//             document.querySelector('div#tick div').style.transition = 'font-size 0.333s';
//             document.querySelector('div#tick div').style.fontSize = '150px';
//           }, 333);
//         }
//       }, 100);
//     } else {
//       setTimeout(() => setIsVisible(false), 500); // Match the duration of the transition
//     }
//   }, [show]);

//   if (!isVisible && !show) return null;

//   return (
//     <div
//       className={`fixed top-0 inset-x-0 flex items-center justify-center z-50 transition-transform duration-500 transform ${
//         show ? 'translate-y-0' : '-translate-y-full'
//       } mt-8`}
//     >
//       <div className="bg-white rounded-lg p-6 w-full max-w-xl relative shadow-lg">
//         <button
//           className="absolute top-3 right-3 text-gray-500 hover:text-gray-700"
//           onClick={onClose}
//         >
//           <IoMdClose size={24} />
//         </button>
//         <div className="text-center">
//           <div id="progress-container" className="relative w-[14rem] h-[14rem] mx-auto">
//             <div id="bkground" className="flex items-center justify-center absolute w-full h-full">
//               <div className="w-[12rem] h-[12rem] bg-blue-300 rounded-full"></div>
//             </div>
//             <div id="whitecircle" className="flex items-center justify-center absolute w-full h-full">
//               <div className="w-[12rem] h-[12rem] bg-white rounded-full"></div>
//             </div>
//             <div id="tick" className="flex items-center justify-center absolute w-full h-full">
//               <div className="text-blue-200 font-bold text-0">✔</div>
//             </div>
//           </div>
//           <h2 className="text-xl font-semibold mt-4">{message}</h2>
//         </div>
//       </div>
//     </div>
//   );
// };

// export default Alert;
