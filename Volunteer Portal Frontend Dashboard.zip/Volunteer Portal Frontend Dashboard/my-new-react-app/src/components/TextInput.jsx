import { FiEdit } from "react-icons/fi";
import { MdInfoOutline } from "react-icons/md";
import React, { useState } from 'react';  // Import React and useState

export default function TextInput({ profile, setProfile, name, handleBlur, editable, toggleEdit }) {
    const [showPhoneTooltip, setShowPhoneTooltip] = React.useState(false);

    const handleInputChange = e => {
        const { name, value } = e.target;
        setProfile({ ...profile, [name]: value });
    };

    return (
      <div className="profile-form-group">
        <label>{name.charAt(0).toUpperCase() + name.slice(1)}</label>
        <div className="profile-form-control">
          <input
     
            name={name}
            disabled={!editable[name]}
            value={profile[name]}
            onChange={handleInputChange}
            onBlur={() => handleBlur(name)}
          />
          {name === 'phone' || name === 'email' ? (
            <MdInfoOutline
              className="info-icon"
              onMouseEnter={() => setShowPhoneTooltip(true)}
              onMouseLeave={() => setShowPhoneTooltip(false)}
            />
          ) : (
            <FiEdit
              className="edit-icon"
              onClick={() => toggleEdit(name)}
            />
          )}
          {showPhoneTooltip && (
            <div className="tooltip">
              Please contact administrator if {name} needs to be changed.
            </div>
          )}
        </div>
      </div>
    );
}
