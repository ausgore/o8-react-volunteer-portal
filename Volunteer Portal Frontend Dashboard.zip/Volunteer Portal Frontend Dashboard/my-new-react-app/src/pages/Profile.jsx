import React, { useEffect, useState } from "react";
import { MdLockReset } from "react-icons/md";
import SideNavbar from "../components/SideNavbar";
import TextInput from "../components/TextInput";
import {
  CustomTextInput,
  CustomDropdownInput,
  CustomCheckboxInput,
} from "../components/CustomTextInput";
import ProgressAlert from "../components/ProgressAlert";

const customFieldSet = "set";

const Profile = () => {
  // This is for profile information
  const [profile, setProfile] = useState({
    name: "Ashley Liz",
    address: "Choa Chu Kang St 5",
    email: "ashleyliz@gmail.com",
    phone: "+65 9876 5543",
    postal_code: "680702",
    diet: "Vegan",
    availability: "Every Saturday",
    gender: "Female",
  });

  // Custom fields
  const [customFields, setCustomFields] = useState(new Map());
  // Hardcoded custom field
  // Feel free to updatedFields.set() more if you want more test data
  useEffect(() => {
    const updatedFields = new Map(customFields);
    updatedFields.set(`${customFieldSet}.favourite_food`, {
      dataType: "String",
      htmlType: "Text",
      label: "favourite food",
      name: "favourite_food",
      optionGroupId: null,
      options: [],
      // This is the default value to show
      value: "chicken",
    });
    updatedFields.set(`${customFieldSet}.interests`, {
      dataType: "Array",
      htmlType: "Checkbox",
      label: "Interests",
      name: "interests",
      options: ["Reading", "Cooking", "Sports"],
      value: ["Reading", "Sports"], // Default selected options
    });

    setCustomFields(updatedFields);
  }, []);

  // How to specific custom field by field name
  // DO NOT CHANGE
  const updateCustomField = (fieldName, value) => {
    const updatedFields = new Map(customFields);
    const key = `${customFieldSet}.${fieldName}`;
    const field = updatedFields.get(key);
    if (field) {
      updatedFields.set(key, { ...field, value });
      setCustomFields(updatedFields);
    }
  };

  const [editable, setEditable] = useState({
    name: false,
    address: false,
    email: false,
    phone: false,
    postal_code: false,
    diet: false,
    gender: false,
    availability: false,
  });

  const toggleEdit = (field) => {
    setEditable((prev) => ({ ...prev, [field]: !prev[field] }));
  };
  const handleBlur = (field) => {
    setEditable((prev) => ({ ...prev, [field]: false }));
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the form from submitting in the traditional way
    console.log("Saving these details:", profile);

    // Here you would typically make a POST request to your server with the profile data
    // For demonstration, let's assume we log and reset editable fields

    setEditable({
      name: false,
      address: false,
      email: false,
      phone: false,
      postal_code: false,
      diet: false,
      gender: false,
      availability: false,
    });
  };

  const handleResetPassword = () => {
    console.log("Reset password initiated for", profile.email);
    // Here you might open a modal for password reset or directly call an API endpoint
    alert("Password reset link sent to " + profile.email);
  };
  const [showAlert, setShowAlert] = useState(false);
  const [alertMessage, setAlertMessage] = useState("");
  const [isSuccess, setIsSuccess] = useState(true); // State to track success or failure
  const saveProfile = () => {
    // Simulate a save action
    // Replace this with your actual save logic
    const saveSuccessful = Math.random() > 0.5; // Simulate a random success or failure

    if (saveSuccessful) {
      setAlertMessage("Profile saved successfully!");
      setIsSuccess(true);
    } else {
      setAlertMessage("Failed to save profile. Please try again.");
      setIsSuccess(false);
    }

    setShowAlert(true);

    // Hide the alert after 3 seconds
    setTimeout(() => {
      setShowAlert(false);
    }, 3500);
  };

  return (
    <div className="profile-page">
      <SideNavbar />

      <main className="profile-content">
        <section className="profile-header">
          <h1>Profile</h1>
        </section>

        <div class="profileInfo">
          <div className="profile-image-container">
            {/* Assuming you will replace this div with an <img> tag */}
            <div className="profile-image"></div>
          </div>
          <div className="profile-name-address">
            <h1 className="profile-name">{profile.name}</h1>
            <p className="profile-address">{profile.address}</p>

            <button
              className="reset-password-button"
              onClick={handleResetPassword}
              title="Reset Password"
            >
              <MdLockReset className="reset-password-icon" />
              Reset Password
            </button>
          </div>
        </div>

        <section className="profile-body">
          {/* <form className="profile-form"> */}
          <div className="row">
            <TextInput
              name={"name"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
            <TextInput
              name={"address"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
          </div>
          <div className="row">
            <TextInput
              name={"phone"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
            <TextInput
              name={"postal_code"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
          </div>
          <div className="row">
            <TextInput
              name={"gender"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
            <TextInput
              name={"email"}
              profile={profile}
              setProfile={setProfile}
              toggleEdit={toggleEdit}
              handleBlur={handleBlur}
              editable={editable}
            />
          </div>
          {/*/////////////////////////////////////////////////////// DEFAULT FIELDS ///////////////////////////////////////////////////*/}
          <div className="row">
            {/* Loops through each custom field */}
            {customFields.size > 0 &&
              [...customFields.values()].map((customField) => {
                switch (customField.htmlType) {
                  case "Text":
                    return (
                      <CustomTextInput
                        key={customField.name}
                        customField={customField}
                        updateCustomField={updateCustomField}
                      />
                    );
                  case "Dropdown":
                    return (
                      <CustomDropdownInput
                        key={customField.name}
                        customField={customField}
                        updateCustomField={updateCustomField}
                      />
                    );
                  case "Radio":
                    return (
                      <CustomCheckboxInput
                        key={customField.name}
                        customField={customField}
                        updateCustomField={updateCustomField}
                      />
                    );
                  case "Checkbox":
                    return (
                      <CustomCheckboxInput
                        key={customField.name}
                        customField={customField}
                        updateCustomField={updateCustomField}
                      />
                    );
                  default:
                    return null;
                }
              })}
          </div>

          <button
            type="submit"
            className="profile-save-button"
            onClick={saveProfile}
          >
            Save
          </button>

          {/* </form>  */}
          <ProgressAlert
            message={alertMessage}
            show={showAlert}
            onClose={() => setShowAlert(false)}
            success={isSuccess} // Pass success state to ProgressAlert
          />
        </section>
      </main>
    </div>
  );
};

export default Profile;
