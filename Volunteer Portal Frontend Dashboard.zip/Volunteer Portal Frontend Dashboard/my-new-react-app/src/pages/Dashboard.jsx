import React, { useEffect, useState } from "react";
import SideNavbar from "../components/SideNavbar";
import { DashboardHeader } from "../components/DashboardHeader";
import { DashboardStats } from "../components/DashboardStats";
import { EventStatus } from "../components/EventStatus";
import { UpcomingEvents } from "../components/UpcomingEvents";

// Sample data
const userData = {
  name: "Ashley Liz",
  email: "ashleyliz@gmail.com",
  phone: "+65 9876 5543",
};
const statsData = { hours: 150, events: 20 };
const eventsData = [
  {
    name: "Kindness Carnival",
    dateTime: "30/04/2024 12:00 PM",
    status: "Upcoming",
    location: "Block 94 Orchard Road",
  },
  {
    name: "HelpingHands Day",
    dateTime: "05/06/2024 10:30 AM",
    status: "Upcoming",
    location: "Block 357 Raffles Quay",
  },
  {
    name: "Greening Our City",
    dateTime: "14/05/2024 11:00 AM",
    status: "No Show",
    location: "Block 680 Bugis Street",
  },
  {
    name: "Skills Share Fair",
    dateTime: "16/04/2024 1:30 PM",
    status: "Canceled",
    location: "Block 913 Kampong Glam Road",
  },
  {
    name: "Food Drive Fiesta",
    dateTime: "10/03/2024 12:00 PM",
    status: "Completed",
    location: "Block 91A Bukit Batok",
  },
  {
    name: "Community Clean-Up",
    dateTime: "01/07/2024 09:00 AM",
    status: "Upcoming",
    location: "East Coast Park",
  },
  {
    name: "Art for All",
    dateTime: "22/07/2024 02:00 PM",
    status: "No Show",
    location: "Block 456 Jurong East",
  },
  {
    name: "Health Awareness Camp",
    dateTime: "18/08/2024 10:00 AM",
    status: "Canceled",
    location: "Block 789 Tanjong Pagar",
  },
  {
    name: "Elderly Care Visit",
    dateTime: "12/09/2024 03:00 PM",
    status: "Completed",
    location: "Block 102 Bedok North",
  },
  {
    name: "Charity Fun Run",
    dateTime: "25/09/2024 06:00 AM",
    status: "Upcoming",
    location: "Marina Bay Sands",
  },
];

const upcomingEventsData = [
  {
    name: "Serving Those in Need",
    dateTime: "19 Apr 2024, 12:00 PM",
    location: "One North St 5",
    participants: 20,
    capacity: 30,
    imageUrl: "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTIROUEKN4tw1c26UjDHnI4RVQBE-YUzS1rJOKShywLnw&s",
  },
  {
    name: "Protecting Our Natural Habitat",
    dateTime: "24 Sep 2024, 10:30 AM",
    location: "Lim Chu Kang St 12",
    participants: 15,
    capacity: 30,
    imageUrl: "https://media.hswstatic.com/eyJidWNrZXQiOiJjb250ZW50Lmhzd3N0YXRpYy5jb20iLCJrZXkiOiJnaWZcL3ZvbHVudGVlci1vcHBvcnR1bml0aWVzLWZvci1raWRzLTEuanBnIiwiZWRpdHMiOnsicmVzaXplIjp7IndpZHRoIjoyOTB9fX0=",
  },
  {
    name: "Making Our Neighborhood Shine",
    dateTime: "7 Dec 2024, 8:00 AM",
    location: "East Coast Park",
    participants: 7,
    capacity: 20,
    imageUrl: "https://imagedelivery.net/WLUarKbmUXuuhDC7PG5_Qw/articles/fa4987215325b577b319ff0bd8020a7d.jpg/public",
  },
];

const Dashboard = () => {
  return (
    <div className="flex h-screen bg-[#F4F5FB]">
      <SideNavbar />
      <div className="flex flex-col w-full">
        <p className="text-black text-[2rem] text-opacity-45 font-bold margin ml-8 mt-8 mb-4">Dashboard</p>
        <div className="overflow-y-auto">
          <DashboardHeader {...userData} />
          <DashboardStats {...statsData} />
          <EventStatus events={eventsData} />
          <UpcomingEvents events={upcomingEventsData} />
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
