import React, { useEffect, useState } from "react";
import SideNavbar from "../components/SideNavbar";
import AllEvent  from "../components/AllEvents";

const AllEvents = () => {
  return (
    <div className="flex h-screen bg-[#F4F5FB]">
      <SideNavbar />
      <div className="flex flex-col w-full">
        <p className="text-black text-[2rem] text-opacity-45 font-bold margin ml-8 mt-8 mb-4">All Events</p>
        <div>
          <AllEvent />
        </div>
      </div>
    </div>
  );
};

export default AllEvents;