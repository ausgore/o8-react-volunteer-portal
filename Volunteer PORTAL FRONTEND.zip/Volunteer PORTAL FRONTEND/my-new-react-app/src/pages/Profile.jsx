import React, { useEffect, useState } from "react";
import { FiEdit } from "react-icons/fi";
import Octopus8 from "../assets/octopus8-logo-landscape.png";
import { Link } from "react-router-dom";
import { FaRegCalendarCheck } from "react-icons/fa";
import { MdLockReset } from "react-icons/md";
import { MdInfoOutline } from "react-icons/md";
import Sidebar from "./Sidebar";
import TextInput from "../components/TextInput";
import CustomTextInput from "../components/CustomTextInput";

const customFieldSet = "set";

const Profile = () => {
  // This is for profile information
  const [profile, setProfile] = useState({
    name: "Ashley Liz",
    address: "Choa Chu Kang St 5",
    email: "ashleyliz@gmail.com",
    phone: "+65 9876 5543",
    postal_code: "680702",
    diet: "Vegan",
    availability: "Every Saturday",
    gender: "Female",
  });
  // Custom fields
  const [customFields, setCustomFields] = useState(new Map());
  // Hardcoded custom field
  // Feel free to updatedFields.set() more if you want more test data
  useEffect(() => {
    const updatedFields = new Map(customFields);
    updatedFields.set(`${customFieldSet}.favourite_food`, {
      dataType: "String",
      htmlType: "Text",
      label: "favourite food",
      name: "favourite_food",
      optionGroupId: null,
      options: [],
      // This is the default value to show
      value: "chicken",
    });
    updatedFields.set(`${customFieldSet}.availability`, {
      dataType: "String",
      htmlType: "Text",
      label: "when are you available",
      name: "availability",
      optionGroupId: null,
      options: [],
      // This is the default value to show
      value: null,
    });

    setCustomFields(updatedFields);
  }, []);

  // How to specific custom field by field name
  // DO NOT CHANGE
  const updateCustomField = (fieldName, value) => {
    const updatedFields = new Map(customFields);
    const key = `${customFieldSet}.${fieldName}`;
    const field = updatedFields.get(key);
    if (field) {
      updatedFields.set(key, { ...field, value });
      setCustomFields(updatedFields);
    }
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setProfile({ ...profile, [name]: value });
  };

  const [editable, setEditable] = useState({
    name: false,
    address: false,
    email: false,
    phone: false,
    postal_code: false,
    diet: false,
    gender: false,
    availability: false,
  });

  const toggleEdit = (field) => {
    setEditable((prev) => ({ ...prev, [field]: !prev[field] }));
  };
  const handleBlur = (field) => {
    setEditable((prev) => ({ ...prev, [field]: false }));
  };

  const handleSubmit = (e) => {
    e.preventDefault(); // Prevent the form from submitting in the traditional way
    console.log("Saving these details:", profile);

    // Here you would typically make a POST request to your server with the profile data
    // For demonstration, let's assume we log and reset editable fields

    setEditable({
      name: false,
      address: false,
      email: false,
      phone: false,
      postal_code: false,
      diet: false,
      gender: false,
      availability: false,
    });

    // Optionally, show a message to the user or trigger a state update
    alert("Profile updated!");
  };

  const handleResetPassword = () => {
    console.log("Reset password initiated for", profile.email);
    // Here you might open a modal for password reset or directly call an API endpoint
    alert("Password reset link sent to " + profile.email);
  };

  const [showEmailTooltip, setShowEmailTooltip] = useState(false);
  const [showPhoneTooltip, setShowPhoneTooltip] = useState(false);

  return (
    <div className="profile-page">
      <Sidebar />

      <main className="profile-content">
        <section className="profile-header">
          <h1>Profile</h1>
        </section>

        <div class="profileInfo">
          <div className="profile-image-container">
            {/* Assuming you will replace this div with an <img> tag */}
            <div className="profile-image"></div>
          </div>
          <div className="profile-name-address">
            <h1 className="profile-name">{profile.name}</h1>
            <p className="profile-address">{profile.address}</p>

            <button
              className="reset-password-button"
              onClick={handleResetPassword}
              title="Reset Password"
            >
              <MdLockReset className="reset-password-icon" />
              Reset Password
            </button>
          </div>
        </div>

        <section className="profile-body">
          <form className="profile-form" onSubmit={handleSubmit}>
            <div className="row">
              <TextInput
                name={"name"}
                profile={profile}
                setProfile={setProfile}
                toggleEdit={toggleEdit}
                handleBlur={handleBlur}
                editable={editable}
              />
              <TextInput
                name={"address"}
                profile={profile}
                setProfile={setProfile}
                toggleEdit={toggleEdit}
                handleBlur={handleBlur}
                editable={editable}
              />
            </div>

            <div className="row">
              <div className="profile-form-group">
                <label>Phone</label>
                <div className="profile-form-control">
                  <input
                    type="profileinfo"
                    name="phone"
                    disabled={!editable.phone}
                    value={profile.phone}
                    onChange={handleInputChange}
                    onBlur={() => handleBlur("phone")}
                  />
                  <MdInfoOutline
                    className="info-icon"
                    onMouseEnter={() => setShowPhoneTooltip(true)}
                    onMouseLeave={() => setShowPhoneTooltip(false)}
                  />
                  {showPhoneTooltip && (
                    <div className="tooltip">
                      Please contact administrator if Number needs to be changed
                    </div>
                  )}
                </div>
              </div>

              <div className="profile-form-group">
                <label>Postal Code</label>
                <div className="profile-form-control">
                  <input
                    type="profileinfo"
                    name="postal_code"
                    disabled={!editable.postal_code}
                    value={profile.postal_code}
                    onChange={handleInputChange}
                    onBlur={() => handleBlur("postal_code")}
                  />
                  <FiEdit
                    className="edit-icon"
                    onClick={() => toggleEdit("postal_code")}
                  />
                </div>
              </div>
            </div>

            <div className="row">
              <div className="profile-form-group">
                <label>Gender</label>
                <div className="profile-form-control">
                  <input
                    type="profileinfo"
                    name="gender"
                    disabled={!editable.gender}
                    value={profile.gender}
                    onChange={handleInputChange}
                    onBlur={() => handleBlur("gender")}
                  />
                  <FiEdit
                    className="edit-icon"
                    onClick={() => toggleEdit("gender")}
                  />
                </div>
              </div>

              <div className="profile-form-group">
                <label>Email</label>
                <div className="profile-form-control">
                  <input
                    type="profileinfo"
                    name="email"
                    disabled={!editable.email}
                    value={profile.email}
                    onBlur={() => handleBlur("email")}
                  />
                  <MdInfoOutline
                    className="info-icon"
                    onMouseEnter={() => setShowEmailTooltip(true)}
                    onMouseLeave={() => setShowEmailTooltip(false)}
                  />
                  {showEmailTooltip && (
                    <div className="tooltip">
                      Please contact administrator if Email needs to be changed
                    </div>
                  )}
                </div>
              </div>
            </div>
            {/*/////////////////////////////////////////////////////// DEFAULT FIELDS ///////////////////////////////////////////////////*/}
            <div className="row">
              {/* Loops through each custom field */}
              {customFields.size > 0 && [...customFields.values()].map((customField) => {
                // TODO: How to dynamically allow editable/blur
                // this will be where I check the customField.htmlType
                // TODO: Add different CustomHTMLTypeInput for each htmlType
                if (customField.htmlType == "Text") return <CustomTextInput customField={customField} updateCustomField={updateCustomField} />
              })}
            </div>
            <button type="submit" className="profile-save-button">
              Save
            </button>
          </form>
        </section>
      </main>
    </div>
  );
};

export default Profile;
