import React, { useEffect, useState } from "react";
import LoginImage from "../assets/LoginImage.png";
import { FaEye } from "react-icons/fa";
import { FaEyeSlash } from "react-icons/fa";
import { AiOutlineMail } from "react-icons/ai";
import { Link } from "react-router-dom";

const Login = () => {
  const [showPassword, setShowPassword] = useState(false);

  return (
    <div className="login-main">
      <div className="login-left">
        <img src={LoginImage} alt="" />
      </div>

      <div className="login-right">
        <div className="login-right-container">
          <div className="login-center">
            <h2>Hello Again!</h2>
            <p>
              Hey there, returning Volunteer! Let's pick up right where we left
              off.
            </p>
            <form>
              <h1>Email</h1>
              <div class="email">
                <input type="email" placeholder="" />
                <div class="emailIcon">
                  <AiOutlineMail></AiOutlineMail>
                </div>
              </div>

              <h1>Password</h1>
              <div className="password">
                <input
                  type={showPassword ? "text" : "password"}
                  placeholder=""
                />
                {showPassword ? (
                  <FaEyeSlash
                    onClick={() => {
                      setShowPassword(!showPassword);
                    }}
                  />
                ) : (
                  <FaEye
                    onClick={() => {
                      setShowPassword(!showPassword);
                    }}
                  />
                )}
              </div>

              <div className="login-center-options">
                <a href="#" className="forgot-pass-link">
                  Forgot password?
                </a>
              </div>

              <div className="login-center-buttons">
                <Link to="/profile" style={{ textDecoration: "none" }}>
                  <button type="button">
                    Login
                  </button>
                </Link>
              </div>
            </form>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Login;
