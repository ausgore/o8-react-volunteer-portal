import { FiEdit } from "react-icons/fi";
import { MdInfoOutline } from "react-icons/md";

export default function TextInput({ profile, setProfile, name, handleBlur, editable, toggleEdit }) {
    const handleInputChange = e => {
        const { name, value } = e.target;
        setProfile({ ...profile, [name]: value });
    }

    return <div className="profile-form-group">
    <label>{name.slice(0, 1).toUpperCase()}{name.slice(1, name.length)}</label>
    <div className="profile-form-control">
      <input
        type="profileinfo"
        name="name"
        disabled={!editable[name]}
        value={profile[name]}
        onChange={handleInputChange}
        onBlur={() => handleBlur(name)}
      />
      <FiEdit
        className="edit-icon"
        onClick={() => toggleEdit(name)}
      />
    </div>
  </div>
}