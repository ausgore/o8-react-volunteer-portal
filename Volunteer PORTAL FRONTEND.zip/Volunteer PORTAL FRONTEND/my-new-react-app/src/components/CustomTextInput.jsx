import { FiEdit } from "react-icons/fi";

export default function CustomTextInput({ customField, updateCustomField }) {
  return (
    <div className="profile-form-group">
      <label>{customField.label}</label>
      <div className="profile-form-control">
        <input
          type="profileinfo"
          name={customField.name}
          value={customField.value}
          onChange={(e) => updateCustomField(customField.name, e.target.value)}
        />
        <FiEdit className="edit-icon" />
      </div>
    </div>
  );
}
