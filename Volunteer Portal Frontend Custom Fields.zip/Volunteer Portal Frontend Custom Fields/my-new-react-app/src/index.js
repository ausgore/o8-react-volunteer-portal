import React from 'react'
import ReactDOM from 'react-dom/client'
import App from './App.jsx'
import './css/Login.css'
import "./css/responsive.css";
import "./css/Profile.css";
import "./css/Sidebar.css"

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>,
)
